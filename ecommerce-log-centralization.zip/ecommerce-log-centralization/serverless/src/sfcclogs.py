import requests
import requests.auth
from bs4 import BeautifulSoup
import os.path
from pathlib import Path
import os
import boto3
import json

s3 = boto3.client('s3')

def lambda_handler(event, context):
    
    CLIENT_ID = "3e5cf106-0414-4ed4-9301-a3036637cdc4"
    CLIENT_SECRET = "GLiijbcHQHRcH99s6WTnUHyV"
    TOKEN_URL = "https://account.demandware.com/dwsso/oauth2/access_token"
    REDIRECT_URI = "https://account.demandware.com/dwsso/oauth2/callback"
    
    #cloudwatch_events = boto3.client('events')
    
    #bucket Name
    bucket_name = 'vf-pc-poc-nora-ecom-common-logs'
    
    
    def get_token(code=None):
        client_auth = requests.auth.HTTPBasicAuth(CLIENT_ID, CLIENT_SECRET)
        post_data = {"grant_type": "client_credentials",
                     "code": code,
                     "redirect_uri": REDIRECT_URI}
        response = requests.post(TOKEN_URL,
                                 auth=client_auth,
                                 data=post_data)
    
        token_json = response.json()
        return token_json["access_token"]
    
    my_token=get_token()
    print(my_token)
    
    
    
    headersAPI = {
        'accept': 'application/json',
        'Authorization': 'Bearer '+ my_token,
    }
    
    params = (
        ('offset', '0'),
        ('limit', '20'),
    )
    
    def download_files(urls):
        for a in soup.find_all('a', href=True):
            url = urls
            a = a['href']
            logs_url = url + a
            r = requests.get(logs_url, headers=headersAPI, params=params, verify=True, stream = True)
            # folder name
            save_path = "download" + ((url.split('/')[2]).split('.')[0])
            # filename
            lname = (logs_url.split('/')[-1])

            s3.put_object(Bucket=bucket_name,Key=('sfcc/'+save_path+'/'+lname),Body=r.content)
            
            print(lname)
    
    
    url_lst = [ "https://development-na02-vfc.demandware.net/on/demandware.servlet/webdav/Sites/Logs/",
                "https://bfvc-002.sandbox.us01.dx.commercecloud.salesforce.com/on/demandware.servlet/webdav/Sites/Logs/",
                "https://bfvc-001.sandbox.us01.dx.commercecloud.salesforce.com/on/demandware.servlet/webdav/Sites/Logs/" ]
    
    for myUrl in url_lst:
        response = requests.get(myUrl, headers=headersAPI, params=params, verify=True, stream = True)
        soup = BeautifulSoup(response.content, 'html.parser')
        f_url = ((myUrl.split('/')[2]))
        url = "https://" + f_url
        download_files(url)
        
    print('done')